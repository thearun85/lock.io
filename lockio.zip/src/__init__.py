"""Distributed Lock Service using pysyncobj ( raft consensus)"""
